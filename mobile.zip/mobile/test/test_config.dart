import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:http/http.dart' as http;

// Arquivo de configuração para testes de integração
// Este arquivo contém configurações e mocks globais para os testes

// Gera os mocks necessários para os testes
@GenerateMocks([http.Client])
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  
  // Configurações globais para testes
  setUp(() {
    // Configurações que serão executadas antes de cada teste
  });
  
  tearDown(() {
    // Limpeza após cada teste
  });
}

// Classe para simular navegação
class MockNavigatorObserver extends Mock implements NavigatorObserver {}

// Classe para simular armazenamento local
class MockStorage extends Mock {
  void write(String key, dynamic value) => super.noSuchMethod(
    Invocation.method(#write, [key, value]),
  );
  
  dynamic read(String key) => super.noSuchMethod(
    Invocation.method(#read, [key]),
  );
}

// Widget de teste para envolver componentes que precisam de contexto
class TestableWidget extends StatelessWidget {
  final Widget child;
  
  const TestableWidget({
    Key? key,
    required this.child,
  }) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: child,
    );
  }
}
