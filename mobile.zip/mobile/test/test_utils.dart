import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';

/// Classe auxiliar para testes de widgets
class TestUtils {
  /// Método para simular o preenchimento de um campo de texto
  static Future<void> preencherCampo(WidgetTester tester, String labelText, String valor) async {
    await tester.enterText(find.widgetWithText(TextField, labelText), valor);
    await tester.pump();
  }
  
  /// Método para simular o clique em um botão com texto específico
  static Future<void> clicarBotao(WidgetTester tester, String textoBotao) async {
    await tester.tap(find.widgetWithText(ElevatedButton, textoBotao));
    await tester.pumpAndSettle();
  }
  
  /// Método para simular o clique em um botão de texto
  static Future<void> clicarBotaoTexto(WidgetTester tester, String textoBotao) async {
    await tester.tap(find.widgetWithText(TextButton, textoBotao));
    await tester.pump();
  }
  
  /// Método para verificar se um texto está presente na tela
  static void verificarTextoPresente(String texto) {
    expect(find.text(texto), findsOneWidget);
  }
  
  /// Método para verificar se um widget está presente na tela
  static void verificarWidgetPresente(Finder finder) {
    expect(finder, findsOneWidget);
  }
  
  /// Método para verificar se um widget não está presente na tela
  static void verificarWidgetAusente(Finder finder) {
    expect(finder, findsNothing);
  }
  
  /// Método para simular o clique em um ícone específico
  static Future<void> clicarIcone(WidgetTester tester, IconData icone) async {
    await tester.tap(find.byIcon(icone));
    await tester.pump();
  }
  
  /// Método para simular a seleção de um item em um dropdown
  static Future<void> selecionarDropdown(WidgetTester tester, String valorAtual, String novoValor) async {
    await tester.tap(find.text(valorAtual));
    await tester.pumpAndSettle();
    await tester.tap(find.text(novoValor).last);
    await tester.pumpAndSettle();
  }
}
