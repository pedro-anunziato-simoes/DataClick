import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mobile/screens/login_screen.dart';
import 'package:mobile/main.dart';

void main() {
  // Grupo de testes para a tela de login
  group('Testes da tela de login', () {
    
    // Teste para verificar se a tela de login é renderizada corretamente
    testWidgets('Deve renderizar a tela de login corretamente', (WidgetTester tester) async {
      // Constrói a tela de login no ambiente de teste
      await tester.pumpWidget(const MaterialApp(home: LoginScreen()));
      
      // Verifica se os elementos principais estão presentes
      expect(find.text('Bem-vindo'), findsOneWidget);
      expect(find.text('Entrar'), findsOneWidget);
      expect(find.text('Esqueci minha senha'), findsOneWidget);
      expect(find.text('Entrar como recrutador'), findsOneWidget);
      
      // Verifica se os campos de entrada estão presentes
      expect(find.widgetWithText(TextField, 'Usuário/CNPJ'), findsOneWidget);
      expect(find.widgetWithText(TextField, 'Senha'), findsOneWidget);
    });
    
    // Teste para verificar a interação com os campos de texto
    testWidgets('Deve permitir inserir texto nos campos de login', (WidgetTester tester) async {
      // Constrói a tela de login no ambiente de teste
      await tester.pumpWidget(const MaterialApp(home: LoginScreen()));
      
      // Insere texto no campo de usuário
      await tester.enterText(find.widgetWithText(TextField, 'Usuário/CNPJ'), 'usuario_teste');
      
      // Insere texto no campo de senha
      await tester.enterText(find.widgetWithText(TextField, 'Senha'), 'senha123');
      
      // Verifica se os textos foram inseridos corretamente
      expect(find.text('usuario_teste'), findsOneWidget);
      expect(find.text('senha123'), findsOneWidget);
    });
    
    // Teste para verificar a navegação ao clicar no botão de entrar
    testWidgets('Deve navegar para a tela inicial ao clicar em Entrar', (WidgetTester tester) async {
      // Cria um widget de teste com navegação
      await tester.pumpWidget(MaterialApp(
        initialRoute: '/login',
        routes: {
          '/login': (context) => const LoginScreen(),
          '/home': (context) => const Scaffold(body: Text('Tela Inicial')),
        },
      ));
      
      // Preenche os campos de login
      await tester.enterText(find.widgetWithText(TextField, 'Usuário/CNPJ'), 'usuario_teste');
      await tester.enterText(find.widgetWithText(TextField, 'Senha'), 'senha123');
      
      // Clica no botão de entrar
      await tester.tap(find.widgetWithText(ElevatedButton, 'Entrar'));
      await tester.pumpAndSettle(); // Aguarda a conclusão da animação de navegação
      
      // Verifica se navegou para a tela inicial
      expect(find.text('Tela Inicial'), findsOneWidget);
    });
    
    // Teste para verificar o comportamento do botão "Esqueci minha senha"
    testWidgets('Deve responder ao clique em Esqueci minha senha', (WidgetTester tester) async {
      // Variável para rastrear se o botão foi clicado
      bool botaoClicado = false;
      
      // Constrói um widget personalizado para testar o botão
      await tester.pumpWidget(MaterialApp(
        home: Scaffold(
          body: TextButton(
            onPressed: () {
              botaoClicado = true;
            },
            child: const Text('Esqueci minha senha'),
          ),
        ),
      ));
      
      // Clica no botão
      await tester.tap(find.text('Esqueci minha senha'));
      await tester.pump();
      
      // Verifica se o botão foi clicado
      expect(botaoClicado, true);
    });
    
    // Teste para verificar o comportamento do botão "Entrar como recrutador"
    testWidgets('Deve responder ao clique em Entrar como recrutador', (WidgetTester tester) async {
      // Variável para rastrear se o botão foi clicado
      bool botaoClicado = false;
      
      // Constrói um widget personalizado para testar o botão
      await tester.pumpWidget(MaterialApp(
        home: Scaffold(
          body: TextButton(
            onPressed: () {
              botaoClicado = true;
            },
            child: const Text('Entrar como recrutador'),
          ),
        ),
      ));
      
      // Clica no botão
      await tester.tap(find.text('Entrar como recrutador'));
      await tester.pump();
      
      // Verifica se o botão foi clicado
      expect(botaoClicado, true);
    });
    
    // Teste para verificar validação de campos vazios
    testWidgets('Deve validar campos vazios ao tentar fazer login', (WidgetTester tester) async {
      // Implementação de um mock para a validação
      // Nota: Este teste é conceitual e precisaria ser adaptado à implementação real
      
      // Constrói a tela de login no ambiente de teste
      await tester.pumpWidget(const MaterialApp(home: LoginScreen()));
      
      // Clica no botão de entrar sem preencher os campos
      await tester.tap(find.widgetWithText(ElevatedButton, 'Entrar'));
      await tester.pump();
      
      // Na implementação real, verificaria mensagens de erro ou comportamento esperado
      // Este é um exemplo conceitual que precisaria ser adaptado
    });
  });
}
