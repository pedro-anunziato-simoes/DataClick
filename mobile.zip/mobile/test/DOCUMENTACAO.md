# Documentação de Testes Automatizados

## Visão Geral

Este documento descreve os testes automatizados implementados para o aplicativo Flutter, com foco nas telas de login e criação de formulários. Os testes foram projetados para garantir o funcionamento correto das interfaces de usuário e das integrações com a API.

## Testes Implementados

### Testes de Interface de Usuário

#### Tela de Login
- Verificação da renderização correta de todos os elementos
- Interação com campos de texto (inserção de usuário e senha)
- Navegação ao clicar no botão de entrar
- Comportamento dos botões "Esqueci minha senha" e "Entrar como recrutador"
- Validação de campos vazios

#### Tela de Criação de Formulários
- Verificação da renderização correta de todos os elementos
- Interação com o campo de título do formulário
- Adição de novos campos ao formulário
- Marcação de campos como obrigatórios
- Adição de opções para campos de seleção
- Remoção de campos adicionados
- Salvamento do formulário completo
- Validação de título vazio

### Testes de Integração com API

- Login com credenciais válidas
- Login com credenciais inválidas
- Criação de formulário
- Obtenção de lista de formulários

## Estrutura dos Arquivos de Teste

```
test/
  ├── login_screen_test.dart
  ├── form_create_screen_test.dart
  ├── api_service_test.dart
  ├── test_utils.dart
  └── test_config.dart
```

## Utilitários de Teste

Foi criada uma classe `TestUtils` que fornece métodos auxiliares para facilitar a escrita e manutenção dos testes:

- `preencherCampo`: Simula o preenchimento de um campo de texto
- `clicarBotao`: Simula o clique em um botão com texto específico
- `clicarBotaoTexto`: Simula o clique em um botão de texto
- `verificarTextoPresente`: Verifica se um texto está presente na tela
- `verificarWidgetPresente`: Verifica se um widget está presente na tela
- `verificarWidgetAusente`: Verifica se um widget não está presente na tela
- `clicarIcone`: Simula o clique em um ícone específico
- `selecionarDropdown`: Simula a seleção de um item em um dropdown

## Abordagem de Teste

Os testes seguem a abordagem AAA (Arrange-Act-Assert):

1. **Arrange**: Preparação do ambiente de teste
2. **Act**: Execução da ação a ser testada
3. **Assert**: Verificação dos resultados esperados

## Considerações Importantes

- Os testes de API utilizam mocks para simular as chamadas de rede, não realizando chamadas reais
- Alguns testes podem precisar de ajustes dependendo da implementação específica de certos componentes
- A cobertura de código pode ser verificada executando `flutter test --coverage`

## Próximos Passos Recomendados

- Implementar testes para as demais telas do aplicativo
- Adicionar testes de integração end-to-end
- Configurar integração contínua para execução automática dos testes
- Expandir os testes de API para cobrir mais cenários
