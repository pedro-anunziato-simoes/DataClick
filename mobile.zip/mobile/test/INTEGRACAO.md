# Guia de Integração e Execução dos Testes

Este documento contém instruções detalhadas para integrar os testes automatizados ao projeto Flutter e executá-los corretamente.

## Estrutura dos Arquivos de Teste

Os seguintes arquivos de teste foram criados:

1. `login_screen_test.dart` - Testes para a tela de login
2. `form_create_screen_test.dart` - Testes para a tela de criação de formulários
3. `api_service_test.dart` - Testes para os serviços de API
4. `test_utils.dart` - Utilitários para facilitar a escrita de testes
5. `test_config.dart` - Configurações globais para os testes

## Integração dos Testes ao Projeto

Para integrar os testes ao projeto Flutter, siga os passos abaixo:

1. Adicione a dependência do Mockito ao projeto (se ainda não estiver adicionada):
   ```
   flutter pub add mockito --dev
   flutter pub add build_runner --dev
   ```

2. Copie os arquivos de teste para a pasta `test/` do projeto:
   ```
   cp /home/ubuntu/testes_temp/*.dart /caminho/para/seu/projeto/mobile/test/
   ```

3. Atualize o arquivo `pubspec.yaml` para incluir as dependências necessárias (se ainda não estiverem incluídas):
   ```yaml
   dev_dependencies:
     flutter_test:
       sdk: flutter
     test: ^1.24.0
     mockito: ^5.4.0
     build_runner: ^2.3.0
   ```

4. Execute o build_runner para gerar os arquivos de mock:
   ```
   flutter pub run build_runner build
   ```

## Executando os Testes

Para executar os testes, utilize os seguintes comandos:

1. Para executar todos os testes:
   ```
   flutter test
   ```

2. Para executar um arquivo de teste específico:
   ```
   flutter test test/login_screen_test.dart
   ```

3. Para executar com cobertura de código:
   ```
   flutter test --coverage
   ```

## Notas Importantes

- Os testes foram implementados considerando a estrutura atual do projeto.
- Alguns testes podem precisar de ajustes dependendo da implementação específica de certos componentes.
- Os testes de API utilizam mocks para simular as chamadas de rede, não realizando chamadas reais.
- A classe `TestUtils` fornece métodos auxiliares para facilitar a escrita de testes adicionais.

## Solução de Problemas

Se encontrar problemas ao executar os testes, verifique:

1. Se todas as dependências foram instaladas corretamente
2. Se os caminhos de importação nos arquivos de teste correspondem à estrutura do seu projeto
3. Se os widgets testados correspondem exatamente aos implementados no projeto

Para qualquer problema adicional, consulte a documentação oficial do Flutter sobre testes: https://docs.flutter.dev/testing
