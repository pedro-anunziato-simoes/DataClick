package com.example.data_click

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
