package com.api.DataClick.controllers;


import com.api.DataClick.entities.EntityAdministrador;
import com.api.DataClick.entities.EntityRecrutador;
import com.api.DataClick.entities.Usuario;
import com.api.DataClick.enums.UserRole;
import com.api.DataClick.services.ServiceAdministrador;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.authentication;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class ControllerAdministradorTest {


    @Mock
    private ServiceAdministrador serviceAdministrador;

    @InjectMocks
    private ControllerAdministrador controller;

    private EntityAdministrador admin;
    private EntityRecrutador usuarioComum;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Configurar admin
        admin = new EntityAdministrador(
                "123456789",
                "Admin Full",
                "senha123",
                "11999998888",
                "admin@dataclick.com",
                UserRole.ADMIN
        );
        admin.setUsuarioId("adm-001");

        // Configurar usuário comum
        usuarioComum = new EntityRecrutador(
                "User Normal",
                "senha456",
                "11999997777",
                "user@dataclick.com",
                "adm-001",
                UserRole.USER,
                List.of()
        );
        usuarioComum.setUsuarioId("user-001");
    }

    private Authentication criarAutenticacao(Usuario usuario) {
        return new UsernamePasswordAuthenticationToken(
                usuario,
                null,
                usuario.getAuthorities()
        );
    }

    @Test
    void removerAdm_ComPermissao_DeveRetornar204() throws Exception {
        Authentication auth = criarAutenticacao(admin);

        mockMvc.perform(delete("/administradores/{id}/remover", "adm-002")
                        .with(authentication(auth)))
                .andExpect(status().isNoContent());

        verify(serviceAdministrador).removerAdm("adm-002");
    }

    @Test
    void removerAdm_SemPermissao_DeveRetornar403() throws Exception {
        Authentication auth = criarAutenticacao(usuarioComum);

        mockMvc.perform(delete("/administradores/{id}/remover", "adm-001")
                        .with(authentication(auth)))
                .andExpect(status().isForbidden());

        verifyNoInteractions(serviceAdministrador);
    }

    @Test
    void infoAdm_ComPermissao_DeveRetornarDados() throws Exception {
        Authentication auth = criarAutenticacao(admin);
        EntityAdministrador admMock = new EntityAdministrador(
                "123456789", "Mock Admin", "senha", "1199999", "mock@adm.com", UserRole.ADMIN
        );

        when(serviceAdministrador.infoAdm("adm-001")).thenReturn(admMock);

        mockMvc.perform(get("/administradores/info")
                        .with(authentication(auth)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("mock@adm.com"));
    }

    @Test
    void alterarEmail_ComPermissao_DeveAtualizar() throws Exception {
        Authentication auth = criarAutenticacao(admin);

        mockMvc.perform(post("/administradores/alterar/email")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("\"novo@email.com\"")
                        .with(authentication(auth)))
                .andExpect(status().isNoContent());

        verify(serviceAdministrador).alterarEmail("novo@email.com", "adm-001");
    }

    @Test
    void alterarSenha_ComPermissao_DeveAtualizar() throws Exception {
        Authentication auth = criarAutenticacao(admin);

        mockMvc.perform(post("/administradores/alterar/senha")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("\"NovaSenha123@\"")
                        .with(authentication(auth)))
                .andExpect(status().isNoContent());

        verify(serviceAdministrador).alterarSenha("NovaSenha123@", "adm-001");
    }

    @Test
    void todosEndpoints_SemAutenticacao_DeveRetornar401() throws Exception {
        mockMvc.perform(delete("/administradores/1/remover"))
                .andExpect(status().isUnauthorized());

        mockMvc.perform(get("/administradores/info"))
                .andExpect(status().isUnauthorized());
    }


}
