package com.api.DataClick.DTO;

public record AuthenticationDTO (String email, String senha ){
}
