package com.api.DataClick.DTO;

public class FormularioDTO {
    private String formularioTituloDto;

    public String getFormularioTituloDto() {
        return formularioTituloDto;
    }
}
