package com.api.DataClick.DTO;

public class RecrutadorDTO {

    private String recrutadorNomeDto;
    private String recrutadoTelefoneDto;
    private String recrutadoEmailDto;
    private String recrutadorSenhaDto;

    public String getRecrutadorNomeDto() {
        return recrutadorNomeDto;
    }

    public String getRecrutadoTelefoneDto() {
        return recrutadoTelefoneDto;
    }

    public String getRecrutadoEmailDto() {
        return recrutadoEmailDto;
    }

    public String getRecrutadorSenhaDto() {
        return recrutadorSenhaDto;
    }
}
