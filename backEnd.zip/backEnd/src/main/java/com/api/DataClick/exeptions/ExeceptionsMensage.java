package com.api.DataClick.exeptions;

public class ExeceptionsMensage {

    public static String CAMPO_NAO_ENCONTRADO = "CAMPO NÃO ENCONTRADO";
    public static String ADM_NAO_ENCONTRADO = "ADMINISTRADOR NÃO ENCONTRADO";
    public static String REC_NAO_ENCONTRADO = "RECRUTADOR NÃO ENCONTRADO";
    public static String FORM_NAO_ENCONTRADO = "FORMULARIO NÃO ENCONTRADO";
    public static String LIST_FORM_NAO_ENCONTRADO = "LISTA DE FORMUALRIOS NÃO ENCONTRADA";
    public static String EVENTO_NAO_ENCONTRADO = "EVENTO NÃO ENCONTRADO";
    public static String RESP_NAO_ENCONTRADA = "RESPOSTA NÃO ENCONTADA";

    public ExeceptionsMensage() {
    }
}
