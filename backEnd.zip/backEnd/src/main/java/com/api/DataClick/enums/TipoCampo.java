package com.api.DataClick.enums;

public enum TipoCampo {
    TEXTO,
    NUMERO,
    DATA,
    CHECKBOX,
    EMAIL
}