package com.api.DataClick.exeptions;

public class ExeptionNaoEncontrado extends RuntimeException{

    public ExeptionNaoEncontrado(String message) {
        super(message);
    }

}
