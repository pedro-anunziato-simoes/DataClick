package com.api.DataClick.DTO;

import java.util.Date;

public class EventoDTO {
    private String eventoTituloDto;
    private String eventoDescricaoDto;
    private Date eventoDataDto;

    public String getEventoTituloDto() {
        return eventoTituloDto;
    }

    public String getEventoDescricaoDto() {
        return eventoDescricaoDto;
    }

    public Date getEventoDataDto() {
        return eventoDataDto;
    }
}
